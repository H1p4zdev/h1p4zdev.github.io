
// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCao2ih2XM8ZkEUpNrl7qs4AZKgq8eitmM",
  authDomain: "esports-hp.firebaseapp.com",
  databaseURL: "https://esports-hp-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "esports-hp",
  storageBucket: "esports-hp.firebasestorage.app",
  messagingSenderId: "578218788593",
  appId: "1:578218788593:web:995d61bdbbfe374bf6cb50",
  measurementId: "G-ELP77R773B"
};

export default firebaseConfig;
